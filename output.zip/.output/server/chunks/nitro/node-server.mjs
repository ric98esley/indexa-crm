globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import 'node-fetch-native/polyfill';
import { Server as Server$1 } from 'node:http';
import { Server } from 'node:https';
import destr from 'destr';
import { defineEventHandler, handleCacheHeaders, createEvent, eventHandler, setHeaders, sendRedirect, proxyRequest, getRequestHeader, setResponseStatus, setResponseHeader, getRequestHeaders, createError, createApp, createRouter as createRouter$1, toNodeListener, fetchWithEvent, lazyEventHandler } from 'h3';
import { createFetch as createFetch$1, Headers } from 'ofetch';
import { createCall, createFetch } from 'unenv/runtime/fetch/index';
import { createHooks } from 'hookable';
import { snakeCase } from 'scule';
import { klona } from 'klona';
import defu, { defuFn } from 'defu';
import { hash } from 'ohash';
import { parseURL, withoutBase, joinURL, getQuery, withQuery, withLeadingSlash, withoutTrailingSlash } from 'ufo';
import { createStorage, prefixStorage } from 'unstorage';
import { toRouteMatcher, createRouter } from 'radix3';
import { promises } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'pathe';
import gracefulShutdown from 'http-graceful-shutdown';

const inlineAppConfig = {};



const appConfig = defuFn(inlineAppConfig);

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {
    "baseUrl": "http://192.168.3.107:3001/v2",
    "nuxtPermissions": {
      "redirectIfNotAllowed": "",
      "fullAccessRoles": ""
    }
  }
};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
const _sharedRuntimeConfig = _deepFreeze(
  _applyEnv(klona(_inlineRuntimeConfig))
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  _applyEnv(runtimeConfig);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
_deepFreeze(klona(appConfig));
function _getEnv(key) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function _applyEnv(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = _getEnv(subKey);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      _applyEnv(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
  return obj;
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

const _assets = {

};

function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

const storage = createStorage({});

storage.mount('/assets', assets$1);

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = hash([opts.integrity, fn, opts]);
  const validate = opts.validate || (() => true);
  async function get(key, resolver, shouldInvalidateCache) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || !validate(entry);
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry)) {
          useStorage().setItem(cacheKey, entry).catch((error) => console.error("[nitro] [cache]", error));
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (opts.swr && entry.value) {
      _resolvePromise.catch(console.error);
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = opts.shouldInvalidateCache?.(...args);
    const entry = await get(key, () => fn(...args), shouldInvalidateCache);
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length > 0 ? hash(args, {}) : "";
}
function escapeKey(key) {
  return key.replace(/[^\dA-Za-z]/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const key = await opts.getKey?.(event);
      if (key) {
        return escapeKey(key);
      }
      const url = event.node.req.originalUrl || event.node.req.url;
      const friendlyName = escapeKey(decodeURI(parseURL(url).pathname)).slice(
        0,
        16
      );
      const urlHash = hash(url);
      return `${friendlyName}.${urlHash}`;
    },
    validate: (entry) => {
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: [opts.integrity, handler]
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const reqProxy = cloneWithProxy(incomingEvent.node.req, { headers: {} });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            for (const header in headers2) {
              this.setHeader(header, headers2[header]);
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.context = incomingEvent.context;
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = headers.Etag || headers.etag || `W/"${hash(body)}"`;
      headers["last-modified"] = headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString();
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(event);
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      event.node.res.setHeader(name, response.headers[name]);
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler() {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      return sendRedirect(
        event,
        routeRules.redirect.to,
        routeRules.redirect.statusCode
      );
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: $fetch.raw,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    const path = new URL(event.node.req.url, "http://localhost").pathname;
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(path, useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

const plugins = [
  
];

function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function normalizeError(error) {
  const cwd = typeof process.cwd === "function" ? process.cwd() : "/";
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}
function trapUnhandledNodeErrors() {
  {
    process.on(
      "unhandledRejection",
      (err) => console.error("[nitro] [unhandledRejection] " + err)
    );
    process.on(
      "uncaughtException",
      (err) => console.error("[nitro]  [uncaughtException] " + err)
    );
  }
}

const errorHandler = (async function errorhandler(error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(error);
  const errorObject = {
    url: event.node.req.url,
    statusCode,
    statusMessage,
    message,
    stack: "",
    data: error.data
  };
  if (error.unhandled || error.fatal) {
    const tags = [
      "[nuxt]",
      "[request error]",
      error.unhandled && "[unhandled]",
      error.fatal && "[fatal]",
      Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
    ].filter(Boolean).join(" ");
    console.error(tags, errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (event.handled) {
    return;
  }
  setResponseStatus(event, errorObject.statusCode !== 200 && errorObject.statusCode || 500, errorObject.statusMessage);
  if (isJsonRequest(event)) {
    setResponseHeader(event, "Content-Type", "application/json");
    event.node.res.end(JSON.stringify(errorObject));
    return;
  }
  const isErrorPage = event.node.req.url?.startsWith("/__nuxt_error");
  const res = !isErrorPage ? await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig().app.baseURL, "/__nuxt_error"), errorObject), {
    headers: getRequestHeaders(event),
    redirect: "manual"
  }).catch(() => null) : null;
  if (!res) {
    const { template } = await import('../error-500.mjs');
    if (event.handled) {
      return;
    }
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    event.node.res.end(template(errorObject));
    return;
  }
  const html = await res.text();
  if (event.handled) {
    return;
  }
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : void 0, res.statusText);
  event.node.res.end(html);
});

const assets = {
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"10be-n8egyE9tcb7sKGr/pYCaQ4uWqxI\"",
    "mtime": "2023-06-26T21:36:52.000Z",
    "size": 4286,
    "path": "../public/favicon.ico"
  },
  "/css/nuxt-google-fonts.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"249f-zx49A2glHl/EWLPz6Rs84ArsPuY\"",
    "mtime": "2023-10-10T16:13:41.167Z",
    "size": 9375,
    "path": "../public/css/nuxt-google-fonts.css"
  },
  "/fonts/Josefin_Sans-400-1.woff2": {
    "type": "font/woff2",
    "etag": "\"10ac-9hBqhony4cVcIfq38sYU5+bkjps\"",
    "mtime": "2023-10-10T16:13:40.977Z",
    "size": 4268,
    "path": "../public/fonts/Josefin_Sans-400-1.woff2"
  },
  "/fonts/Josefin_Sans-400-2.woff2": {
    "type": "font/woff2",
    "etag": "\"25e4-57LBXUvQuFmbCM3cLo+20myDWME\"",
    "mtime": "2023-10-10T16:13:40.936Z",
    "size": 9700,
    "path": "../public/fonts/Josefin_Sans-400-2.woff2"
  },
  "/fonts/Josefin_Sans-400-3.woff2": {
    "type": "font/woff2",
    "etag": "\"3064-dEU6+0RJNIk5n2fLBH45wk0Rr+U\"",
    "mtime": "2023-10-10T16:13:40.976Z",
    "size": 12388,
    "path": "../public/fonts/Josefin_Sans-400-3.woff2"
  },
  "/fonts/Lato-100-4.woff2": {
    "type": "font/woff2",
    "etag": "\"14f4-zAETq0e9F1v5YmqJ8zcyIvPzAWI\"",
    "mtime": "2023-10-10T16:13:40.913Z",
    "size": 5364,
    "path": "../public/fonts/Lato-100-4.woff2"
  },
  "/fonts/Lato-100-5.woff2": {
    "type": "font/woff2",
    "etag": "\"5404-CQaXXXCFbvPfGuPZHbXSloeYHD8\"",
    "mtime": "2023-10-10T16:13:41.086Z",
    "size": 21508,
    "path": "../public/fonts/Lato-100-5.woff2"
  },
  "/fonts/Lato-300-6.woff2": {
    "type": "font/woff2",
    "etag": "\"15f8-GykTAfJcxd2hDaBMB87HHhd0Z7I\"",
    "mtime": "2023-10-10T16:13:41.106Z",
    "size": 5624,
    "path": "../public/fonts/Lato-300-6.woff2"
  },
  "/fonts/Lato-300-7.woff2": {
    "type": "font/woff2",
    "etag": "\"5ac4-OIBCM6Kar5ddVX/hTnYsYnvvduA\"",
    "mtime": "2023-10-10T16:13:40.968Z",
    "size": 23236,
    "path": "../public/fonts/Lato-300-7.woff2"
  },
  "/fonts/Raleway-100-10.woff2": {
    "type": "font/woff2",
    "etag": "\"1c98-njqR17u+fMoNUWdzuWMED5YrEf4\"",
    "mtime": "2023-10-10T16:13:41.115Z",
    "size": 7320,
    "path": "../public/fonts/Raleway-100-10.woff2"
  },
  "/fonts/Raleway-100-11.woff2": {
    "type": "font/woff2",
    "etag": "\"41e8-KUwoAp+REYNYJG/+oIADYxbcjPA\"",
    "mtime": "2023-10-10T16:13:41.035Z",
    "size": 16872,
    "path": "../public/fonts/Raleway-100-11.woff2"
  },
  "/fonts/Raleway-100-12.woff2": {
    "type": "font/woff2",
    "etag": "\"5628-7TQQgg/EMrFFZL6idBBKEEMYeGo\"",
    "mtime": "2023-10-10T16:13:41.055Z",
    "size": 22056,
    "path": "../public/fonts/Raleway-100-12.woff2"
  },
  "/fonts/Raleway-100-13.woff2": {
    "type": "font/woff2",
    "etag": "\"68a4-QO/mYPqyBnYwCoV89I32HDyRDBA\"",
    "mtime": "2023-10-10T16:13:40.991Z",
    "size": 26788,
    "path": "../public/fonts/Raleway-100-13.woff2"
  },
  "/fonts/Raleway-100-14.woff2": {
    "type": "font/woff2",
    "etag": "\"64e4-e6SLNInNitXo/Eg2x1WMcgFc0EI\"",
    "mtime": "2023-10-10T16:13:41.080Z",
    "size": 25828,
    "path": "../public/fonts/Raleway-100-14.woff2"
  },
  "/fonts/Raleway-100-15.woff2": {
    "type": "font/woff2",
    "etag": "\"2ba8-ssa1RzGYvkEppy1iXjJ8VaYSRAE\"",
    "mtime": "2023-10-10T16:13:41.059Z",
    "size": 11176,
    "path": "../public/fonts/Raleway-100-15.woff2"
  },
  "/fonts/Raleway-100-16.woff2": {
    "type": "font/woff2",
    "etag": "\"7818-aToM8hGxYHwunVpVJLIK55KSX5k\"",
    "mtime": "2023-10-10T16:13:41.029Z",
    "size": 30744,
    "path": "../public/fonts/Raleway-100-16.woff2"
  },
  "/fonts/Raleway-100-17.woff2": {
    "type": "font/woff2",
    "etag": "\"bc50-5xE4Ams4r8RD+2DaX/wiRMT16xE\"",
    "mtime": "2023-10-10T16:13:41.150Z",
    "size": 48208,
    "path": "../public/fonts/Raleway-100-17.woff2"
  },
  "/fonts/Raleway-100-8.woff2": {
    "type": "font/woff2",
    "etag": "\"382c-roja/8+iajE4gkJZjMkm8IsBNok\"",
    "mtime": "2023-10-10T16:13:41.125Z",
    "size": 14380,
    "path": "../public/fonts/Raleway-100-8.woff2"
  },
  "/fonts/Raleway-100-9.woff2": {
    "type": "font/woff2",
    "etag": "\"30c8-ErjlCFemKljzQNJz8ELy0RwuBd4\"",
    "mtime": "2023-10-10T16:13:41.115Z",
    "size": 12488,
    "path": "../public/fonts/Raleway-100-9.woff2"
  },
  "/fonts/Raleway-400-18.woff2": {
    "type": "font/woff2",
    "etag": "\"68a4-QO/mYPqyBnYwCoV89I32HDyRDBA\"",
    "mtime": "2023-10-10T16:13:41.021Z",
    "size": 26788,
    "path": "../public/fonts/Raleway-400-18.woff2"
  },
  "/fonts/Raleway-400-19.woff2": {
    "type": "font/woff2",
    "etag": "\"64e4-e6SLNInNitXo/Eg2x1WMcgFc0EI\"",
    "mtime": "2023-10-10T16:13:41.003Z",
    "size": 25828,
    "path": "../public/fonts/Raleway-400-19.woff2"
  },
  "/fonts/Raleway-400-20.woff2": {
    "type": "font/woff2",
    "etag": "\"2ba8-ssa1RzGYvkEppy1iXjJ8VaYSRAE\"",
    "mtime": "2023-10-10T16:13:41.086Z",
    "size": 11176,
    "path": "../public/fonts/Raleway-400-20.woff2"
  },
  "/fonts/Raleway-400-21.woff2": {
    "type": "font/woff2",
    "etag": "\"7818-aToM8hGxYHwunVpVJLIK55KSX5k\"",
    "mtime": "2023-10-10T16:13:40.991Z",
    "size": 30744,
    "path": "../public/fonts/Raleway-400-21.woff2"
  },
  "/fonts/Raleway-400-22.woff2": {
    "type": "font/woff2",
    "etag": "\"bc50-5xE4Ams4r8RD+2DaX/wiRMT16xE\"",
    "mtime": "2023-10-10T16:13:41.162Z",
    "size": 48208,
    "path": "../public/fonts/Raleway-400-22.woff2"
  },
  "/fonts/Roboto-400-23.woff2": {
    "type": "font/woff2",
    "etag": "\"3bf0-3SKkH6IexKSo0p/Tadm+6RnLmKw\"",
    "mtime": "2023-10-10T16:13:41.086Z",
    "size": 15344,
    "path": "../public/fonts/Roboto-400-23.woff2"
  },
  "/fonts/Roboto-400-24.woff2": {
    "type": "font/woff2",
    "etag": "\"259c-ESovxfT/m4XuOnBvqbjEf3mwWTM\"",
    "mtime": "2023-10-10T16:13:41.106Z",
    "size": 9628,
    "path": "../public/fonts/Roboto-400-24.woff2"
  },
  "/fonts/Roboto-400-25.woff2": {
    "type": "font/woff2",
    "etag": "\"5cc-TfOeql0acP87XSiKdL96Ro51g+8\"",
    "mtime": "2023-10-10T16:13:41.062Z",
    "size": 1484,
    "path": "../public/fonts/Roboto-400-25.woff2"
  },
  "/fonts/Roboto-400-26.woff2": {
    "type": "font/woff2",
    "etag": "\"1bc8-fPvEFcRbInSlmXJV++wPtTu+Mn0\"",
    "mtime": "2023-10-10T16:13:41.011Z",
    "size": 7112,
    "path": "../public/fonts/Roboto-400-26.woff2"
  },
  "/fonts/Roboto-400-27.woff2": {
    "type": "font/woff2",
    "etag": "\"15b8-EJzUxUNb1mFDkbuHIsR8KHyWsuw\"",
    "mtime": "2023-10-10T16:13:41.099Z",
    "size": 5560,
    "path": "../public/fonts/Roboto-400-27.woff2"
  },
  "/fonts/Roboto-400-28.woff2": {
    "type": "font/woff2",
    "etag": "\"2e60-t0NUh3DEbZBa4boGMQvAAcWH/o4\"",
    "mtime": "2023-10-10T16:13:41.105Z",
    "size": 11872,
    "path": "../public/fonts/Roboto-400-28.woff2"
  },
  "/fonts/Roboto-400-29.woff2": {
    "type": "font/woff2",
    "etag": "\"3d80-fKnFln87uL/+qyS2ObScHn0D+lI\"",
    "mtime": "2023-10-10T16:13:41.027Z",
    "size": 15744,
    "path": "../public/fonts/Roboto-400-29.woff2"
  },
  "/img/gana_logo.png": {
    "type": "image/png",
    "etag": "\"206a2-XqkQ5h/aSJIQ3hkkAhPOhagEYFs\"",
    "mtime": "2023-09-18T11:58:13.309Z",
    "size": 132770,
    "path": "../public/img/gana_logo.png"
  },
  "/img/logo.png": {
    "type": "image/png",
    "etag": "\"72e6-PvlU+u7Z/Ex7GEWPG5Ump1bcTGw\"",
    "mtime": "2023-07-07T15:34:08.196Z",
    "size": 29414,
    "path": "../public/img/logo.png"
  },
  "/_nuxt/add.ab051ab0.js": {
    "type": "application/javascript",
    "etag": "\"71e-yCZEw7s8xjdUzhi0k33jqpDrdoM\"",
    "mtime": "2023-10-10T16:14:32.463Z",
    "size": 1822,
    "path": "../public/_nuxt/add.ab051ab0.js"
  },
  "/_nuxt/add.eced3955.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"83d-JMRDnznzAMagIys8FqhAGu9ySG8\"",
    "mtime": "2023-10-10T16:14:32.421Z",
    "size": 2109,
    "path": "../public/_nuxt/add.eced3955.css"
  },
  "/_nuxt/add.ecf76264.js": {
    "type": "application/javascript",
    "etag": "\"47b2-fKsstF7rHdJc2xrPeOovy8HtzVE\"",
    "mtime": "2023-10-10T16:14:32.490Z",
    "size": 18354,
    "path": "../public/_nuxt/add.ecf76264.js"
  },
  "/_nuxt/aria.06e80a3d.js": {
    "type": "application/javascript",
    "etag": "\"1d7-H9b+yTXK0pTyMWJjAdmzSavV8nk\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 471,
    "path": "../public/_nuxt/aria.06e80a3d.js"
  },
  "/_nuxt/arrays.e667dc24.js": {
    "type": "application/javascript",
    "etag": "\"5b-o/7qLFCJN1jY/hhQpHxvTvqyRsc\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 91,
    "path": "../public/_nuxt/arrays.e667dc24.js"
  },
  "/_nuxt/assign.6fb20387.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"e9-xXwY3LQ35aj4yK7b4ONayQDLy30\"",
    "mtime": "2023-10-10T16:14:32.421Z",
    "size": 233,
    "path": "../public/_nuxt/assign.6fb20387.css"
  },
  "/_nuxt/assign.df53e944.js": {
    "type": "application/javascript",
    "etag": "\"278b-oVxM9Z4SbV5HXWSZJJRIbFgA1m0\"",
    "mtime": "2023-10-10T16:14:32.478Z",
    "size": 10123,
    "path": "../public/_nuxt/assign.df53e944.js"
  },
  "/_nuxt/auth.a09b93b6.js": {
    "type": "application/javascript",
    "etag": "\"1ac-d4UN+ElL8MjQ8VSNhh36rjM+JV0\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 428,
    "path": "../public/_nuxt/auth.a09b93b6.js"
  },
  "/_nuxt/config.744a4245.js": {
    "type": "application/javascript",
    "etag": "\"a9-4ABQh+/JKlwMorXAii/VWLsG5YQ\"",
    "mtime": "2023-10-10T16:14:32.446Z",
    "size": 169,
    "path": "../public/_nuxt/config.744a4245.js"
  },
  "/_nuxt/Copy.c9640b6c.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"108a-ObFIzC0u7TVSvBo00Quxv3EZa0I\"",
    "mtime": "2023-10-10T16:14:32.425Z",
    "size": 4234,
    "path": "../public/_nuxt/Copy.c9640b6c.css"
  },
  "/_nuxt/Copy.vue.17424b76.js": {
    "type": "application/javascript",
    "etag": "\"19cf-o0gWuaNXphmOjXg7ZAwd0D3f0xQ\"",
    "mtime": "2023-10-10T16:14:32.478Z",
    "size": 6607,
    "path": "../public/_nuxt/Copy.vue.17424b76.js"
  },
  "/_nuxt/default.43f4cf25.js": {
    "type": "application/javascript",
    "etag": "\"ab85-U4O0k6xkEX5jqPAtLWlnei0v/hU\"",
    "mtime": "2023-10-10T16:14:32.500Z",
    "size": 43909,
    "path": "../public/_nuxt/default.43f4cf25.js"
  },
  "/_nuxt/default.71685246.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"529e-X8JlqApDeWxVeTmeGbHuMFx3sHo\"",
    "mtime": "2023-10-10T16:14:32.442Z",
    "size": 21150,
    "path": "../public/_nuxt/default.71685246.css"
  },
  "/_nuxt/el-button.2f175304.js": {
    "type": "application/javascript",
    "etag": "\"4adc-9anNq9XndjkdGNq/apMvTof7nhk\"",
    "mtime": "2023-10-10T16:14:32.497Z",
    "size": 19164,
    "path": "../public/_nuxt/el-button.2f175304.js"
  },
  "/_nuxt/el-button.7e4b7aaa.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3dc4-iWzoz/Rbmwb20BPw5Cd8rEMq/HA\"",
    "mtime": "2023-10-10T16:14:32.436Z",
    "size": 15812,
    "path": "../public/_nuxt/el-button.7e4b7aaa.css"
  },
  "/_nuxt/el-card.69b564bc.js": {
    "type": "application/javascript",
    "etag": "\"369-lF6E9xafHgTUYDKv4hIJ01Rdj+U\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 873,
    "path": "../public/_nuxt/el-card.69b564bc.js"
  },
  "/_nuxt/el-card.6c182248.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"303-b/M64w9gVpogf3JfKEHJouPmkew\"",
    "mtime": "2023-10-10T16:14:32.425Z",
    "size": 771,
    "path": "../public/_nuxt/el-card.6c182248.css"
  },
  "/_nuxt/el-date-picker.3b23abae.js": {
    "type": "application/javascript",
    "etag": "\"129e8-d2SJpteb9c2ojERYFJ0SfdLVh+A\"",
    "mtime": "2023-10-10T16:14:32.500Z",
    "size": 76264,
    "path": "../public/_nuxt/el-date-picker.3b23abae.js"
  },
  "/_nuxt/el-date-picker.db43681d.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"5d9a-SSX1lYH1j9JexZ1cKpmrgylhD6w\"",
    "mtime": "2023-10-10T16:14:32.421Z",
    "size": 23962,
    "path": "../public/_nuxt/el-date-picker.db43681d.css"
  },
  "/_nuxt/el-descriptions.22bee64e.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"d69-eEOQdbM0BBmB6U/qFBXeDJaBiac\"",
    "mtime": "2023-10-10T16:14:32.425Z",
    "size": 3433,
    "path": "../public/_nuxt/el-descriptions.22bee64e.css"
  },
  "/_nuxt/el-descriptions.f4dfe797.js": {
    "type": "application/javascript",
    "etag": "\"111f-HmZhVN4MPVOV5UZy7rgn2nMZw80\"",
    "mtime": "2023-10-10T16:14:32.478Z",
    "size": 4383,
    "path": "../public/_nuxt/el-descriptions.f4dfe797.js"
  },
  "/_nuxt/el-dialog.afbbbbf9.js": {
    "type": "application/javascript",
    "etag": "\"15ad-bnR2SCBnDjCN2POVMECagAGQAyk\"",
    "mtime": "2023-10-10T16:14:32.488Z",
    "size": 5549,
    "path": "../public/_nuxt/el-dialog.afbbbbf9.js"
  },
  "/_nuxt/el-dialog.be61bd17.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"e1d-QHsUbOq6PXutwHltxv2S5MH86+w\"",
    "mtime": "2023-10-10T16:14:32.425Z",
    "size": 3613,
    "path": "../public/_nuxt/el-dialog.be61bd17.css"
  },
  "/_nuxt/el-form.7235a9a0.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"f0d-qCH0MR9J+ccrp40iuwPw59h7yJI\"",
    "mtime": "2023-10-10T16:14:32.436Z",
    "size": 3853,
    "path": "../public/_nuxt/el-form.7235a9a0.css"
  },
  "/_nuxt/el-form.a6138862.js": {
    "type": "application/javascript",
    "etag": "\"7524-L1ICVrrKLEfpM2eBRdHnTS7vjKQ\"",
    "mtime": "2023-10-10T16:14:32.497Z",
    "size": 29988,
    "path": "../public/_nuxt/el-form.a6138862.js"
  },
  "/_nuxt/el-image-viewer.06d58037.js": {
    "type": "application/javascript",
    "etag": "\"2560-qb0NiZ3oxadd+UgVyv4f+iZbQUA\"",
    "mtime": "2023-10-10T16:14:32.497Z",
    "size": 9568,
    "path": "../public/_nuxt/el-image-viewer.06d58037.js"
  },
  "/_nuxt/el-image-viewer.7448703b.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"978-Jkx28+wETr+9FpZzy19YR8C/sZM\"",
    "mtime": "2023-10-10T16:14:32.442Z",
    "size": 2424,
    "path": "../public/_nuxt/el-image-viewer.7448703b.css"
  },
  "/_nuxt/el-input.1b8f4f33.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3078-zLC6UidQLBWOXL45UdV1S21oOZI\"",
    "mtime": "2023-10-10T16:14:32.436Z",
    "size": 12408,
    "path": "../public/_nuxt/el-input.1b8f4f33.css"
  },
  "/_nuxt/el-input.c8e84939.js": {
    "type": "application/javascript",
    "etag": "\"448e-aIjcf5qLRq1M2gHUKZwr4WNhlHk\"",
    "mtime": "2023-10-10T16:14:32.490Z",
    "size": 17550,
    "path": "../public/_nuxt/el-input.c8e84939.js"
  },
  "/_nuxt/el-loading.2355ccf9.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"69b-jXJOp2gs2ULaRD8LZLBBimJKajI\"",
    "mtime": "2023-10-10T16:14:32.436Z",
    "size": 1691,
    "path": "../public/_nuxt/el-loading.2355ccf9.css"
  },
  "/_nuxt/el-loading.27e76e45.js": {
    "type": "application/javascript",
    "etag": "\"1194-rKr03yXTf2S/J+hck6b20yYsxG8\"",
    "mtime": "2023-10-10T16:14:32.484Z",
    "size": 4500,
    "path": "../public/_nuxt/el-loading.27e76e45.js"
  },
  "/_nuxt/el-main.729f8130.js": {
    "type": "application/javascript",
    "etag": "\"882-vG1zGj76BkWUjQKmfC+2UoC2qMk\"",
    "mtime": "2023-10-10T16:14:32.490Z",
    "size": 2178,
    "path": "../public/_nuxt/el-main.729f8130.js"
  },
  "/_nuxt/el-main.7f48f59f.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"311-PgJiuQLtObcJL6fHjPw6z0nIbDw\"",
    "mtime": "2023-10-10T16:14:32.442Z",
    "size": 785,
    "path": "../public/_nuxt/el-main.7f48f59f.css"
  },
  "/_nuxt/el-overlay.1b5bc707.js": {
    "type": "application/javascript",
    "etag": "\"11de-V4M0OZGHUxhNbrAlqd8RYL2NysQ\"",
    "mtime": "2023-10-10T16:14:32.494Z",
    "size": 4574,
    "path": "../public/_nuxt/el-overlay.1b5bc707.js"
  },
  "/_nuxt/el-overlay.6e0625dd.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"b8-76nQgG8l8UzzOEcfS6sooTMGznw\"",
    "mtime": "2023-10-10T16:14:32.442Z",
    "size": 184,
    "path": "../public/_nuxt/el-overlay.6e0625dd.css"
  },
  "/_nuxt/el-page-header.2598a4c7.js": {
    "type": "application/javascript",
    "etag": "\"a2d-6exI2FLzKRBD0baTNccQhueVCT4\"",
    "mtime": "2023-10-10T16:14:32.488Z",
    "size": 2605,
    "path": "../public/_nuxt/el-page-header.2598a4c7.js"
  },
  "/_nuxt/el-page-header.f723b780.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"5b0-WSBcSrkOzt0hN/kVGpVph65Whe8\"",
    "mtime": "2023-10-10T16:14:32.425Z",
    "size": 1456,
    "path": "../public/_nuxt/el-page-header.f723b780.css"
  },
  "/_nuxt/el-radio.205d3c00.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3303-1k5jpQ//jRbwF4gvs4QIiKzlW8s\"",
    "mtime": "2023-10-10T16:14:32.421Z",
    "size": 13059,
    "path": "../public/_nuxt/el-radio.205d3c00.css"
  },
  "/_nuxt/el-radio.9dec7cd2.js": {
    "type": "application/javascript",
    "etag": "\"7116-qF7b80R5Tz1qXqwG0xy/j+lUQC4\"",
    "mtime": "2023-10-10T16:14:32.490Z",
    "size": 28950,
    "path": "../public/_nuxt/el-radio.9dec7cd2.js"
  },
  "/_nuxt/el-row.13e5e05d.js": {
    "type": "application/javascript",
    "etag": "\"919-+0JroS2PxPjbhQNN9VgyYDR0WPc\"",
    "mtime": "2023-10-10T16:14:32.490Z",
    "size": 2329,
    "path": "../public/_nuxt/el-row.13e5e05d.js"
  },
  "/_nuxt/el-row.a555356e.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"822e-3MjWGsQGiYOnpewHyEC+3APtZag\"",
    "mtime": "2023-10-10T16:14:32.436Z",
    "size": 33326,
    "path": "../public/_nuxt/el-row.a555356e.css"
  },
  "/_nuxt/el-scrollbar.6aa3b3c3.js": {
    "type": "application/javascript",
    "etag": "\"c774-ePt7x6W4yADd9fu3B6cr08MJSL8\"",
    "mtime": "2023-10-10T16:14:32.500Z",
    "size": 51060,
    "path": "../public/_nuxt/el-scrollbar.6aa3b3c3.js"
  },
  "/_nuxt/el-scrollbar.cac23b3d.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"de2-Rg216mFD6P1m4NpiDjVUPwi/eyU\"",
    "mtime": "2023-10-10T16:14:32.436Z",
    "size": 3554,
    "path": "../public/_nuxt/el-scrollbar.cac23b3d.css"
  },
  "/_nuxt/el-select.97b73766.js": {
    "type": "application/javascript",
    "etag": "\"926c-WI7JmxcjsydSpwlqIK8wUE/SQAQ\"",
    "mtime": "2023-10-10T16:14:32.500Z",
    "size": 37484,
    "path": "../public/_nuxt/el-select.97b73766.js"
  },
  "/_nuxt/el-select.a1f8f57e.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3d88-4C4d1yGOlrCo4b4hyAj2xW0lRx4\"",
    "mtime": "2023-10-10T16:14:32.436Z",
    "size": 15752,
    "path": "../public/_nuxt/el-select.a1f8f57e.css"
  },
  "/_nuxt/el-switch.96f4fc52.js": {
    "type": "application/javascript",
    "etag": "\"15e6-X4xuDGEK7tFG9I+VtJBmAHiK2co\"",
    "mtime": "2023-10-10T16:14:32.488Z",
    "size": 5606,
    "path": "../public/_nuxt/el-switch.96f4fc52.js"
  },
  "/_nuxt/el-switch.e0856ead.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"f4e-7KHKfELgm39cYdoek67imGgUGjc\"",
    "mtime": "2023-10-10T16:14:32.425Z",
    "size": 3918,
    "path": "../public/_nuxt/el-switch.e0856ead.css"
  },
  "/_nuxt/el-table.5590d4c9.js": {
    "type": "application/javascript",
    "etag": "\"140b1-AkRvcgDOfBi43ldgoaCuXhDuTps\"",
    "mtime": "2023-10-10T16:14:32.503Z",
    "size": 82097,
    "path": "../public/_nuxt/el-table.5590d4c9.js"
  },
  "/_nuxt/el-table.c2b5989a.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"5d76-/eTK+/2JplzQyc18haSZdtkS/6I\"",
    "mtime": "2023-10-10T16:14:32.436Z",
    "size": 23926,
    "path": "../public/_nuxt/el-table.c2b5989a.css"
  },
  "/_nuxt/el-tabs.439412e0.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"422d-oXOv0QcINI9ui01j9xOfDjoLJa0\"",
    "mtime": "2023-10-10T16:14:32.425Z",
    "size": 16941,
    "path": "../public/_nuxt/el-tabs.439412e0.css"
  },
  "/_nuxt/el-tabs.bfd111dc.js": {
    "type": "application/javascript",
    "etag": "\"2439-Ep+7t7tGODXZclY/+9LBEQOANnU\"",
    "mtime": "2023-10-10T16:14:32.484Z",
    "size": 9273,
    "path": "../public/_nuxt/el-tabs.bfd111dc.js"
  },
  "/_nuxt/el-tooltip.c8d4650c.js": {
    "type": "application/javascript",
    "etag": "\"3b2-zGiiSHpNXpLmyIlXSFGuA5uAQPM\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 946,
    "path": "../public/_nuxt/el-tooltip.c8d4650c.js"
  },
  "/_nuxt/entry.0090b14e.js": {
    "type": "application/javascript",
    "etag": "\"332a7-RN5vdmKSD6Gf5z/D+/VgDA5Wubg\"",
    "mtime": "2023-10-10T16:14:32.500Z",
    "size": 209575,
    "path": "../public/_nuxt/entry.0090b14e.js"
  },
  "/_nuxt/entry.ccb9c3bc.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"62b0-iG3YMlwt5Vsy9ZZXDPpq8WFdtQU\"",
    "mtime": "2023-10-10T16:14:32.421Z",
    "size": 25264,
    "path": "../public/_nuxt/entry.ccb9c3bc.css"
  },
  "/_nuxt/error-404.95c28eb4.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"e70-L8dF9pJCW0qi7de8Az4GyBoTHvI\"",
    "mtime": "2023-10-10T16:14:32.421Z",
    "size": 3696,
    "path": "../public/_nuxt/error-404.95c28eb4.css"
  },
  "/_nuxt/error-404.d60a3fc3.js": {
    "type": "application/javascript",
    "etag": "\"907-ZzgeQ5JEtLCPSL3vwUU97bveF4g\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 2311,
    "path": "../public/_nuxt/error-404.d60a3fc3.js"
  },
  "/_nuxt/error-500.10d8d953.js": {
    "type": "application/javascript",
    "etag": "\"78b-J9bNxdIJNXjsZ2eU0oyXgjLV5zM\"",
    "mtime": "2023-10-10T16:14:32.477Z",
    "size": 1931,
    "path": "../public/_nuxt/error-500.10d8d953.js"
  },
  "/_nuxt/error-500.e798523c.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7e0-QP983DB9m1oiDr87r1V1AYEhrfo\"",
    "mtime": "2023-10-10T16:14:32.421Z",
    "size": 2016,
    "path": "../public/_nuxt/error-500.e798523c.css"
  },
  "/_nuxt/fetch.108b924b.js": {
    "type": "application/javascript",
    "etag": "\"2db5-4bGGukUNTp0jFFWb/Uq452cYp0w\"",
    "mtime": "2023-10-10T16:14:32.461Z",
    "size": 11701,
    "path": "../public/_nuxt/fetch.108b924b.js"
  },
  "/_nuxt/get.794dc035.js": {
    "type": "application/javascript",
    "etag": "\"1bc6-sALZ8aZmvhoO8gDC/bjj2xliXD4\"",
    "mtime": "2023-10-10T16:14:32.490Z",
    "size": 7110,
    "path": "../public/_nuxt/get.794dc035.js"
  },
  "/_nuxt/history.83446281.js": {
    "type": "application/javascript",
    "etag": "\"1842-3Riw3FAnpiBVDdLh/+apKbl4Q9k\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 6210,
    "path": "../public/_nuxt/history.83446281.js"
  },
  "/_nuxt/Icon.31621e1e.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"43-Goh9NAiYJuEQljAvCLCepbumWqg\"",
    "mtime": "2023-10-10T16:14:32.436Z",
    "size": 67,
    "path": "../public/_nuxt/Icon.31621e1e.css"
  },
  "/_nuxt/Icon.a02456ac.js": {
    "type": "application/javascript",
    "etag": "\"5352-ReDJRToMO2yjpFrqLNmf5cIER6U\"",
    "mtime": "2023-10-10T16:14:32.500Z",
    "size": 21330,
    "path": "../public/_nuxt/Icon.a02456ac.js"
  },
  "/_nuxt/IconCSS.6edc7bff.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"102-F5FEFmWVF9wjE1jgjQsXqGhD4Cc\"",
    "mtime": "2023-10-10T16:14:32.442Z",
    "size": 258,
    "path": "../public/_nuxt/IconCSS.6edc7bff.css"
  },
  "/_nuxt/IconCSS.d3a45eb1.js": {
    "type": "application/javascript",
    "etag": "\"3b3-S+OqAsbAbndsaISls1FZg7o4B+Q\"",
    "mtime": "2023-10-10T16:14:32.494Z",
    "size": 947,
    "path": "../public/_nuxt/IconCSS.d3a45eb1.js"
  },
  "/_nuxt/index.17b1ec2f.js": {
    "type": "application/javascript",
    "etag": "\"19b1-ToWukQNPWN+Y2P25WfwdLRZAjf0\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 6577,
    "path": "../public/_nuxt/index.17b1ec2f.js"
  },
  "/_nuxt/index.22128e44.js": {
    "type": "application/javascript",
    "etag": "\"2671-rW78aoYt3BPbkm3v6fc7GcA3mF4\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 9841,
    "path": "../public/_nuxt/index.22128e44.js"
  },
  "/_nuxt/index.267a8b92.js": {
    "type": "application/javascript",
    "etag": "\"95-z4Ypsd1CaH4hbAi4/zIYePFhoQk\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 149,
    "path": "../public/_nuxt/index.267a8b92.js"
  },
  "/_nuxt/index.2b06f472.js": {
    "type": "application/javascript",
    "etag": "\"d6-0ZaGmEDCL+0Gp8xx9R4VumA9NoQ\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 214,
    "path": "../public/_nuxt/index.2b06f472.js"
  },
  "/_nuxt/index.2efb5f23.js": {
    "type": "application/javascript",
    "etag": "\"70a3-Mw61TJ72IoNdt5tfTu4EbssoaKc\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 28835,
    "path": "../public/_nuxt/index.2efb5f23.js"
  },
  "/_nuxt/index.387abce2.js": {
    "type": "application/javascript",
    "etag": "\"18bf-doUhV1BnLr7kxJgZDAnUxz9Apas\"",
    "mtime": "2023-10-10T16:14:32.463Z",
    "size": 6335,
    "path": "../public/_nuxt/index.387abce2.js"
  },
  "/_nuxt/index.4ed70a0f.js": {
    "type": "application/javascript",
    "etag": "\"3899-IEk7sH0l7hFjuSJx/dK9hhGaCjk\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 14489,
    "path": "../public/_nuxt/index.4ed70a0f.js"
  },
  "/_nuxt/index.6b2a25c1.js": {
    "type": "application/javascript",
    "etag": "\"18fd-o0RKm8mhh65lFhANa3RZfKS1nXc\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 6397,
    "path": "../public/_nuxt/index.6b2a25c1.js"
  },
  "/_nuxt/index.6f01ad79.js": {
    "type": "application/javascript",
    "etag": "\"dc-U4ZbflLZhRUZsKz7rO44oO9NH7U\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 220,
    "path": "../public/_nuxt/index.6f01ad79.js"
  },
  "/_nuxt/index.702fbeb1.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"ce0-5lo2lt9QvZdaGUYmAgungg5orYE\"",
    "mtime": "2023-10-10T16:14:32.425Z",
    "size": 3296,
    "path": "../public/_nuxt/index.702fbeb1.css"
  },
  "/_nuxt/index.7350a090.js": {
    "type": "application/javascript",
    "etag": "\"202f-jgu0vBSj4CDNQr0UbD+dNMPKbZo\"",
    "mtime": "2023-10-10T16:14:32.477Z",
    "size": 8239,
    "path": "../public/_nuxt/index.7350a090.js"
  },
  "/_nuxt/index.80f2889e.js": {
    "type": "application/javascript",
    "etag": "\"25b6-SW59+Vg2CaXdr0bXils+hiaH17o\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 9654,
    "path": "../public/_nuxt/index.80f2889e.js"
  },
  "/_nuxt/index.81eb2e54.js": {
    "type": "application/javascript",
    "etag": "\"4159-hAjKmFnBmgGv5WftBVLLWQqJvCQ\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 16729,
    "path": "../public/_nuxt/index.81eb2e54.js"
  },
  "/_nuxt/index.86ea4d52.js": {
    "type": "application/javascript",
    "etag": "\"24ec-14CauFMqRh6mC2EQrpXNfPw9NAo\"",
    "mtime": "2023-10-10T16:14:32.461Z",
    "size": 9452,
    "path": "../public/_nuxt/index.86ea4d52.js"
  },
  "/_nuxt/index.8c68e873.js": {
    "type": "application/javascript",
    "etag": "\"1ada-hUd5hxgmE3diUi3oeNtI62Mz61c\"",
    "mtime": "2023-10-10T16:14:32.446Z",
    "size": 6874,
    "path": "../public/_nuxt/index.8c68e873.js"
  },
  "/_nuxt/index.b0168516.js": {
    "type": "application/javascript",
    "etag": "\"11e1-sE9J4nks2gN7bGLsy2Ie+V/k2ao\"",
    "mtime": "2023-10-10T16:14:32.490Z",
    "size": 4577,
    "path": "../public/_nuxt/index.b0168516.js"
  },
  "/_nuxt/index.b14aa678.js": {
    "type": "application/javascript",
    "etag": "\"1c8f-cQ9lLzJY5+BpoUhh6vlCgcooNp4\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 7311,
    "path": "../public/_nuxt/index.b14aa678.js"
  },
  "/_nuxt/index.b2d17dec.js": {
    "type": "application/javascript",
    "etag": "\"167c-7cf52A3ltqSEg1pFKykeTDf191w\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 5756,
    "path": "../public/_nuxt/index.b2d17dec.js"
  },
  "/_nuxt/index.b2f545ea.js": {
    "type": "application/javascript",
    "etag": "\"ca-u5SVVKN5mCT3rwM0O6OSzVerNhY\"",
    "mtime": "2023-10-10T16:14:32.442Z",
    "size": 202,
    "path": "../public/_nuxt/index.b2f545ea.js"
  },
  "/_nuxt/index.b9de4643.js": {
    "type": "application/javascript",
    "etag": "\"d8-5HFXsHNLpiuK2cUOoiY+CEb9hQQ\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 216,
    "path": "../public/_nuxt/index.b9de4643.js"
  },
  "/_nuxt/index.c3c01e7d.js": {
    "type": "application/javascript",
    "etag": "\"95-z4Ypsd1CaH4hbAi4/zIYePFhoQk\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 149,
    "path": "../public/_nuxt/index.c3c01e7d.js"
  },
  "/_nuxt/index.d591edc6.js": {
    "type": "application/javascript",
    "etag": "\"3284-Xpm0R8ZoykRitswZPh9LtfEWp+Y\"",
    "mtime": "2023-10-10T16:14:32.484Z",
    "size": 12932,
    "path": "../public/_nuxt/index.d591edc6.js"
  },
  "/_nuxt/index.e40b52d5.js": {
    "type": "application/javascript",
    "etag": "\"2cd2-/OPHnSUfpOlv3I+8iXvUa0zKTDc\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 11474,
    "path": "../public/_nuxt/index.e40b52d5.js"
  },
  "/_nuxt/index.f4c9d1f6.js": {
    "type": "application/javascript",
    "etag": "\"3e09-YTdGNDmbSTCC2aPPFgBfPtrCj88\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 15881,
    "path": "../public/_nuxt/index.f4c9d1f6.js"
  },
  "/_nuxt/Josefin_Sans-400-1.440ea5d9.woff2": {
    "type": "font/woff2",
    "etag": "\"10ac-9hBqhony4cVcIfq38sYU5+bkjps\"",
    "mtime": "2023-10-10T16:14:32.397Z",
    "size": 4268,
    "path": "../public/_nuxt/Josefin_Sans-400-1.440ea5d9.woff2"
  },
  "/_nuxt/Josefin_Sans-400-2.3d9620f5.woff2": {
    "type": "font/woff2",
    "etag": "\"25e4-57LBXUvQuFmbCM3cLo+20myDWME\"",
    "mtime": "2023-10-10T16:14:32.407Z",
    "size": 9700,
    "path": "../public/_nuxt/Josefin_Sans-400-2.3d9620f5.woff2"
  },
  "/_nuxt/Josefin_Sans-400-3.24a6ddc7.woff2": {
    "type": "font/woff2",
    "etag": "\"3064-dEU6+0RJNIk5n2fLBH45wk0Rr+U\"",
    "mtime": "2023-10-10T16:14:32.407Z",
    "size": 12388,
    "path": "../public/_nuxt/Josefin_Sans-400-3.24a6ddc7.woff2"
  },
  "/_nuxt/Lato-100-4.63aee53d.woff2": {
    "type": "font/woff2",
    "etag": "\"14f4-zAETq0e9F1v5YmqJ8zcyIvPzAWI\"",
    "mtime": "2023-10-10T16:14:32.407Z",
    "size": 5364,
    "path": "../public/_nuxt/Lato-100-4.63aee53d.woff2"
  },
  "/_nuxt/Lato-100-5.a79b4c65.woff2": {
    "type": "font/woff2",
    "etag": "\"5404-CQaXXXCFbvPfGuPZHbXSloeYHD8\"",
    "mtime": "2023-10-10T16:14:32.407Z",
    "size": 21508,
    "path": "../public/_nuxt/Lato-100-5.a79b4c65.woff2"
  },
  "/_nuxt/Lato-300-6.c9455def.woff2": {
    "type": "font/woff2",
    "etag": "\"15f8-GykTAfJcxd2hDaBMB87HHhd0Z7I\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 5624,
    "path": "../public/_nuxt/Lato-300-6.c9455def.woff2"
  },
  "/_nuxt/Lato-300-7.115f6a62.woff2": {
    "type": "font/woff2",
    "etag": "\"5ac4-OIBCM6Kar5ddVX/hTnYsYnvvduA\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 23236,
    "path": "../public/_nuxt/Lato-300-7.115f6a62.woff2"
  },
  "/_nuxt/login.77c3f952.js": {
    "type": "application/javascript",
    "etag": "\"aad-/jQe1Ba8FOcMYu4vRa92IlEedgk\"",
    "mtime": "2023-10-10T16:14:32.478Z",
    "size": 2733,
    "path": "../public/_nuxt/login.77c3f952.js"
  },
  "/_nuxt/login.bc4c9d11.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3b9-5jvwXPfs/WwuZUEGDbhVF4U3xkk\"",
    "mtime": "2023-10-10T16:14:32.425Z",
    "size": 953,
    "path": "../public/_nuxt/login.bc4c9d11.css"
  },
  "/_nuxt/Logo.vue.d517b38c.js": {
    "type": "application/javascript",
    "etag": "\"17c-Jju6Z1+6W44sCj7bm78AgtCQiII\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 380,
    "path": "../public/_nuxt/Logo.vue.d517b38c.js"
  },
  "/_nuxt/nuxt-link.a2c7e948.js": {
    "type": "application/javascript",
    "etag": "\"1104-0jQyJIHMVnhtx2hh7fvwFi5wydc\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 4356,
    "path": "../public/_nuxt/nuxt-link.a2c7e948.js"
  },
  "/_nuxt/plugin-vue_export-helper.1cff8a04.js": {
    "type": "application/javascript",
    "etag": "\"59-DRITqS/KEYd0y9ZdVDCQ1f/k5J4\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 89,
    "path": "../public/_nuxt/plugin-vue_export-helper.1cff8a04.js"
  },
  "/_nuxt/print.108d7955.js": {
    "type": "application/javascript",
    "etag": "\"1241-wBFq51nZkNevtMQzvuaDOhoUk+I\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 4673,
    "path": "../public/_nuxt/print.108d7955.js"
  },
  "/_nuxt/print.8129b378.js": {
    "type": "application/javascript",
    "etag": "\"182-PXoFMJx7XTsx2hI69TzNqHIHrH0\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 386,
    "path": "../public/_nuxt/print.8129b378.js"
  },
  "/_nuxt/print.a3dfc1af.js": {
    "type": "application/javascript",
    "etag": "\"1853-oK7s1RsBZGdv9SeOWfUtIOpFvIo\"",
    "mtime": "2023-10-10T16:14:32.470Z",
    "size": 6227,
    "path": "../public/_nuxt/print.a3dfc1af.js"
  },
  "/_nuxt/print.dfb21dfe.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1a4-bZT5UVTNzRNfBoWsOoy4at2ojvM\"",
    "mtime": "2023-10-10T16:14:32.421Z",
    "size": 420,
    "path": "../public/_nuxt/print.dfb21dfe.css"
  },
  "/_nuxt/Raleway-100-10.180c5252.woff2": {
    "type": "font/woff2",
    "etag": "\"1c98-njqR17u+fMoNUWdzuWMED5YrEf4\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 7320,
    "path": "../public/_nuxt/Raleway-100-10.180c5252.woff2"
  },
  "/_nuxt/Raleway-100-11.00f305df.woff2": {
    "type": "font/woff2",
    "etag": "\"41e8-KUwoAp+REYNYJG/+oIADYxbcjPA\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 16872,
    "path": "../public/_nuxt/Raleway-100-11.00f305df.woff2"
  },
  "/_nuxt/Raleway-100-12.7ed87dc0.woff2": {
    "type": "font/woff2",
    "etag": "\"5628-7TQQgg/EMrFFZL6idBBKEEMYeGo\"",
    "mtime": "2023-10-10T16:14:32.409Z",
    "size": 22056,
    "path": "../public/_nuxt/Raleway-100-12.7ed87dc0.woff2"
  },
  "/_nuxt/Raleway-100-13.2ab70013.woff2": {
    "type": "font/woff2",
    "etag": "\"68a4-QO/mYPqyBnYwCoV89I32HDyRDBA\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 26788,
    "path": "../public/_nuxt/Raleway-100-13.2ab70013.woff2"
  },
  "/_nuxt/Raleway-100-14.89f273f4.woff2": {
    "type": "font/woff2",
    "etag": "\"64e4-e6SLNInNitXo/Eg2x1WMcgFc0EI\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 25828,
    "path": "../public/_nuxt/Raleway-100-14.89f273f4.woff2"
  },
  "/_nuxt/Raleway-100-15.3eb84c62.woff2": {
    "type": "font/woff2",
    "etag": "\"2ba8-ssa1RzGYvkEppy1iXjJ8VaYSRAE\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 11176,
    "path": "../public/_nuxt/Raleway-100-15.3eb84c62.woff2"
  },
  "/_nuxt/Raleway-100-16.4db78ee9.woff2": {
    "type": "font/woff2",
    "etag": "\"7818-aToM8hGxYHwunVpVJLIK55KSX5k\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 30744,
    "path": "../public/_nuxt/Raleway-100-16.4db78ee9.woff2"
  },
  "/_nuxt/Raleway-100-17.8cbc049d.woff2": {
    "type": "font/woff2",
    "etag": "\"bc50-5xE4Ams4r8RD+2DaX/wiRMT16xE\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 48208,
    "path": "../public/_nuxt/Raleway-100-17.8cbc049d.woff2"
  },
  "/_nuxt/Raleway-100-8.8a34c28d.woff2": {
    "type": "font/woff2",
    "etag": "\"382c-roja/8+iajE4gkJZjMkm8IsBNok\"",
    "mtime": "2023-10-10T16:14:32.407Z",
    "size": 14380,
    "path": "../public/_nuxt/Raleway-100-8.8a34c28d.woff2"
  },
  "/_nuxt/Raleway-100-9.b1719fd0.woff2": {
    "type": "font/woff2",
    "etag": "\"30c8-ErjlCFemKljzQNJz8ELy0RwuBd4\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 12488,
    "path": "../public/_nuxt/Raleway-100-9.b1719fd0.woff2"
  },
  "/_nuxt/Roboto-400-23.b7ef2cd1.woff2": {
    "type": "font/woff2",
    "etag": "\"3bf0-3SKkH6IexKSo0p/Tadm+6RnLmKw\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 15344,
    "path": "../public/_nuxt/Roboto-400-23.b7ef2cd1.woff2"
  },
  "/_nuxt/Roboto-400-24.495d38d4.woff2": {
    "type": "font/woff2",
    "etag": "\"259c-ESovxfT/m4XuOnBvqbjEf3mwWTM\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 9628,
    "path": "../public/_nuxt/Roboto-400-24.495d38d4.woff2"
  },
  "/_nuxt/Roboto-400-26.daf51ab5.woff2": {
    "type": "font/woff2",
    "etag": "\"1bc8-fPvEFcRbInSlmXJV++wPtTu+Mn0\"",
    "mtime": "2023-10-10T16:14:32.408Z",
    "size": 7112,
    "path": "../public/_nuxt/Roboto-400-26.daf51ab5.woff2"
  },
  "/_nuxt/Roboto-400-27.77b24796.woff2": {
    "type": "font/woff2",
    "etag": "\"15b8-EJzUxUNb1mFDkbuHIsR8KHyWsuw\"",
    "mtime": "2023-10-10T16:14:32.411Z",
    "size": 5560,
    "path": "../public/_nuxt/Roboto-400-27.77b24796.woff2"
  },
  "/_nuxt/Roboto-400-28.3c23eb02.woff2": {
    "type": "font/woff2",
    "etag": "\"2e60-t0NUh3DEbZBa4boGMQvAAcWH/o4\"",
    "mtime": "2023-10-10T16:14:32.421Z",
    "size": 11872,
    "path": "../public/_nuxt/Roboto-400-28.3c23eb02.woff2"
  },
  "/_nuxt/Roboto-400-29.f6734f81.woff2": {
    "type": "font/woff2",
    "etag": "\"3d80-fKnFln87uL/+qyS2ObScHn0D+lI\"",
    "mtime": "2023-10-10T16:14:32.421Z",
    "size": 15744,
    "path": "../public/_nuxt/Roboto-400-29.f6734f81.woff2"
  },
  "/_nuxt/use-form-item.015b1356.js": {
    "type": "application/javascript",
    "etag": "\"890-675+AyaTh4Is08M4LemSsIqmepo\"",
    "mtime": "2023-10-10T16:14:32.456Z",
    "size": 2192,
    "path": "../public/_nuxt/use-form-item.015b1356.js"
  },
  "/_nuxt/useDebounce.594fab14.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"185e-kALDjoaR8609mg3YcmpO2dz//ws\"",
    "mtime": "2023-10-10T16:14:32.436Z",
    "size": 6238,
    "path": "../public/_nuxt/useDebounce.594fab14.css"
  },
  "/_nuxt/useDebounce.bc412a0f.js": {
    "type": "application/javascript",
    "etag": "\"2ef6-f/P8654U9OrsuOkfJcZkbkNo6C0\"",
    "mtime": "2023-10-10T16:14:32.490Z",
    "size": 12022,
    "path": "../public/_nuxt/useDebounce.bc412a0f.js"
  },
  "/_nuxt/useFilterObject.bd6efcad.js": {
    "type": "application/javascript",
    "etag": "\"64-cHvbljiI+im4VbgF3k44Ly9uemA\"",
    "mtime": "2023-10-10T16:14:32.442Z",
    "size": 100,
    "path": "../public/_nuxt/useFilterObject.bd6efcad.js"
  },
  "/_nuxt/_plugin-vue_export-helper.c27b6911.js": {
    "type": "application/javascript",
    "etag": "\"5b-eFCz/UrraTh721pgAl0VxBNR1es\"",
    "mtime": "2023-10-10T16:14:32.445Z",
    "size": 91,
    "path": "../public/_nuxt/_plugin-vue_export-helper.c27b6911.js"
  }
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _f4b49z = eventHandler((event) => {
  if (event.node.req.method && !METHODS.has(event.node.req.method)) {
    return;
  }
  let id = decodeURIComponent(
    withLeadingSlash(
      withoutTrailingSlash(parseURL(event.node.req.url).pathname)
    )
  );
  let asset;
  const encodingHeader = String(
    event.node.req.headers["accept-encoding"] || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    event.node.res.setHeader("Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.node.res.removeHeader("cache-control");
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = event.node.req.headers["if-none-match"] === asset.etag;
  if (ifNotMatch) {
    if (!event.handled) {
      event.node.res.statusCode = 304;
      event.node.res.end();
    }
    return;
  }
  const ifModifiedSinceH = event.node.req.headers["if-modified-since"];
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    if (!event.handled) {
      event.node.res.statusCode = 304;
      event.node.res.end();
    }
    return;
  }
  if (asset.type && !event.node.res.getHeader("Content-Type")) {
    event.node.res.setHeader("Content-Type", asset.type);
  }
  if (asset.etag && !event.node.res.getHeader("ETag")) {
    event.node.res.setHeader("ETag", asset.etag);
  }
  if (asset.mtime && !event.node.res.getHeader("Last-Modified")) {
    event.node.res.setHeader("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.node.res.getHeader("Content-Encoding")) {
    event.node.res.setHeader("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.node.res.getHeader("Content-Length")) {
    event.node.res.setHeader("Content-Length", asset.size);
  }
  return readAsset(id);
});

const _lazy_zfdyi0 = () => import('../handlers/renderer.mjs');

const handlers = [
  { route: '', handler: _f4b49z, lazy: false, middleware: true, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_zfdyi0, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_zfdyi0, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const h3App = createApp({
    debug: destr(false),
    onError: errorHandler
  });
  const router = createRouter$1();
  h3App.use(createRouteRulesHandler());
  const localCall = createCall(toNodeListener(h3App));
  const localFetch = createFetch(localCall, globalThis.fetch);
  const $fetch = createFetch$1({
    fetch: localFetch,
    Headers,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(
    eventHandler((event) => {
      event.context.nitro = event.context.nitro || {};
      const envContext = event.node.req.__unenv__;
      if (envContext) {
        Object.assign(event.context, envContext);
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
    })
  );
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch
  };
  for (const plugin of plugins) {
    plugin(app);
  }
  return app;
}
const nitroApp = createNitroApp();
const useNitroApp = () => nitroApp;

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT, 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  gracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((err) => {
          console.error(err);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const listener = server.listen(port, host, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { useRuntimeConfig as a, getRouteRules as g, nodeServer as n, useNitroApp as u };
//# sourceMappingURL=node-server.mjs.map
