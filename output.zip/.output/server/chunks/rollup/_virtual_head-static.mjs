const _virtual__headStatic = {"headTags":"<meta charset=\"utf-8\">\n<title>Indexa ERP</title>\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<meta name=\"Control de mantenimientos y soportes\" content=\"Indexa ERP\">\n<link rel=\"icon\" type=\"image/x-icon\" href=\"/favicon.ico\">","bodyTags":"","bodyTagsOpen":"","htmlAttrs":"","bodyAttrs":""};

export { _virtual__headStatic as default };
//# sourceMappingURL=_virtual_head-static.mjs.map
