const i=e=>{let r={};for(let t in e)e[t]!==void 0&&e[t]!==""&&(r[t]=e[t]);return r};export{i as u};
