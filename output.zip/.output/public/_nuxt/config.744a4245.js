import{bw as p,I as o,b7 as i}from"./entry.0090b14e.js";const f={},t=p(f);function s(){const n=i();return n._appConfig||(n._appConfig=o(t)),n._appConfig}export{s as u};
