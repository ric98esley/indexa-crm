import{_ as e}from"./_plugin-vue_export-helper.c27b6911.js";const n={};function r(c,t){return null}const o=e(n,[["render",r]]);export{o as default};
